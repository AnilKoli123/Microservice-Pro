from flask import Flask, jsonify
import requests

app = Flask(__name__)

orders = {
    101: {"id": 101, "item": "Mango Juice", "user_id": 1},
    102: {"id": 102, "item": "Apple Juice", "user_id": 2}
}

@app.route("/orders/<int:order_id>")
def get_order(order_id):
    order = orders.get(order_id)
    if not order:
        return jsonify({"error": "Order not found"}), 404
    
    # Fetch user info from user-service
    try:
        response = requests.get(f"http://user-service:5001/users/{order['user_id']}")
        user = response.json()
        order["user"] = user
    except Exception as e:
        order["user"] = {"error": "Could not fetch user"}

    return jsonify(order)

@app.route("/")
def home():
    return "Order Service is running!"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5002)
